.onLoad <- function(libname, pkgname) {
  #download_BLUPF90(dest_folder = paste0(.libPaths()[1],"/blupf90"))
  print("download blupf90 software")
}
